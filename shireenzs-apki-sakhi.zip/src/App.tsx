import React, { useState, useEffect, useRef, useCallback } from 'react';
import { DeviceFrame } from './components/DeviceFrame';
import { SpectsHUD } from './components/SpectsHUD';
import { WatchFace } from './components/WatchFace';
import { PhoneHub } from './components/PhoneHub';
import { BreathingGuide } from './components/BreathingGuide';
import {
  DeviceMode,
  PulseTelemetry,
  ChatMessage,
  SUPPORTED_LANGUAGES,
  BiometricAlert,
  SeniorRoutineState,
} from './types';
import {
  speakText,
  stopSpeech,
  createSpeechRecognizer,
  triggerHapticBuzz,
  playHUDAlertPing,
} from './utils/audio';

export default function App() {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('phone');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('hi-IN');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [voiceAudioEnabled, setVoiceAudioEnabled] = useState<boolean>(true);
  const [isLoadingAI, setIsLoadingAI] = useState<boolean>(false);
  const [latestAlert, setLatestAlert] = useState<string | undefined>();
  const [showBreathingModal, setShowBreathingModal] = useState<boolean>(false);

  // Live Pulse Wearable Telemetry State
  const [telemetry, setTelemetry] = useState<PulseTelemetry>({
    bpm: 74,
    hrv: 52,
    stressLevel: 24,
    spo2: 98,
    bodyTemp: 36.6,
    status: 'Normal Resting',
    activity: 'Resting',
    isConnected: true,
    batteryLevel: 88,
    deviceModel: 'Sakhi Pulse-Ring v3',
    lastUpdated: 'Just now',
  });

  // Senior Citizen Daily Routine State (Pills, Water, Family, Accessibility)
  const [routineState, setRoutineState] = useState<SeniorRoutineState>({
    elderName: 'Dadaji / Ammi / Elder',
    glassesOfWater: 4,
    targetGlasses: 8,
    lastWaterTime: '10:30 AM',
    morningWalkCompleted: true,
    eveningRestCompleted: false,
    medicines: [
      {
        id: '1',
        name: 'Amlodipine (Blood Pressure)',
        dosage: '5 mg (1 Tab)',
        time: '08:30 AM',
        instructions: 'After breakfast with water',
        taken: true,
        category: 'morning',
      },
      {
        id: '2',
        name: 'Calcium & Vitamin D3',
        dosage: '500 mg (1 Tab)',
        time: '01:30 PM',
        instructions: 'After lunch with warm water',
        taken: false,
        category: 'afternoon',
      },
      {
        id: '3',
        name: 'Metformin / Heart Tonic',
        dosage: '500 mg (1 Tab)',
        time: '08:30 PM',
        instructions: 'After dinner with water',
        taken: false,
        category: 'night',
      },
    ],
    emergencyContacts: [
      { name: 'Rahul (Son)', relation: 'Beta / Son', phone: '+91 98765 43210' },
      { name: 'Dr. S. K. Verma', relation: 'Family Physician', phone: '+91 91234 56789' },
      { name: 'Priya (Daughter)', relation: 'Beti / Daughter', phone: '+91 98111 22334' },
    ],
    seniorModeLargeFont: true,
  });

  // Conversation history
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'ai',
      text: 'Namaste! Main hoon Shireenzs Apki Sakhi — aapki apni sehat aur dainik saathi. Connected to your pulse ring (74 BPM). Main aapke Spects, Watch aur Phone par aapki dawai, paani, pulse aur sukoon ka poora khayal rakhungi. Kisi bhi bhasha mein baat karein.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      pulseAtMoment: 74,
    },
  ]);

  const [alerts, setAlerts] = useState<BiometricAlert[]>([]);
  const speechRecognizerRef = useRef<any>(null);

  // Simulate physiological micro-fluctuations every 3.5s
  useEffect(() => {
    const timer = setInterval(() => {
      setTelemetry((prev) => {
        if (prev.activity === 'Workout' || prev.activity === 'Panic Attack') {
          return prev;
        }
        const delta = Math.floor(Math.random() * 3) - 1;
        const newBpm = Math.max(55, Math.min(105, prev.bpm + delta));
        return {
          ...prev,
          bpm: newBpm,
        };
      });
    }, 3500);

    return () => clearInterval(timer);
  }, []);

  // Proactive speech synthesis helper
  const triggerVoiceOutput = useCallback(
    (text: string) => {
      if (!voiceAudioEnabled) return;
      setIsSpeaking(true);
      speakText(text, selectedLanguage, () => {
        setIsSpeaking(false);
      });
    },
    [voiceAudioEnabled, selectedLanguage]
  );

  // Send message to full-stack Gemini API
  const handleSendMessage = useCallback(
    async (text: string, isVoice = false) => {
      const userMsg: ChatMessage = {
        id: Date.now().toString(),
        sender: 'user',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        pulseAtMoment: telemetry.bpm,
        isVoiceInput: isVoice,
      };

      setMessages((prev) => [...prev, userMsg]);
      setIsLoadingAI(true);

      const targetLang =
        SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi';

      try {
        const response = await fetch('/api/pulse-ai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            language: targetLang,
            pulseData: telemetry,
            history: messages.slice(-5),
          }),
        });

        const data = await response.json();
        const replyText =
          data.reply ||
          'Aapka pulse bilkul theek hai. Main aapke saath hoon, bilkul chinta na karein.';

        const aiMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          pulseAtMoment: telemetry.bpm,
        };

        setMessages((prev) => [...prev, aiMsg]);
        triggerVoiceOutput(replyText);
      } catch (err) {
        console.error('AI chat error:', err);
        const fallbackText = `Aapka pulse ${telemetry.bpm} BPM hai. Dawai aur paani ka dhyan rakhein, main aapke saath hoon.`;
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            sender: 'ai',
            text: fallbackText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            pulseAtMoment: telemetry.bpm,
          },
        ]);
        triggerVoiceOutput(fallbackText);
      } finally {
        setIsLoadingAI(false);
      }
    },
    [messages, telemetry, selectedLanguage, triggerVoiceOutput]
  );

  // Proactive Telemetry Anomaly Intervention
  const triggerProactiveAlert = useCallback(
    async (eventType: string, customBpm: number) => {
      triggerHapticBuzz();
      playHUDAlertPing('alert');

      const targetLang =
        SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi';

      try {
        const res = await fetch('/api/pulse-ai/alert-advisor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            eventType,
            pulseData: { ...telemetry, bpm: customBpm },
            language: targetLang,
          }),
        });

        const data = await res.json();
        const alertMsg =
          data.alertMessage ||
          `Sakhi Alert: Pulse ${customBpm} BPM par pauhanch gaya hai. Kripya aaram se baith jayein aur thoda paani piyein.`;

        setLatestAlert(alertMsg);

        const newAlert: BiometricAlert = {
          id: Date.now().toString(),
          type: customBpm > 115 ? 'warning' : 'info',
          title: `Pulse Alert: ${eventType.toUpperCase()}`,
          message: alertMsg,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          bpm: customBpm,
          read: false,
        };

        setAlerts((prev) => [newAlert, ...prev]);

        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            sender: 'ai',
            text: `[SAKHI PROACTIVE ALERT]: ${alertMsg}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            pulseAtMoment: customBpm,
          },
        ]);

        triggerVoiceOutput(alertMsg);
      } catch (e) {
        const fallbackMsg = `Kripya dhyan dein: Pulse ${customBpm} BPM hai. Gehri aur shaant saans lein.`;
        setLatestAlert(fallbackMsg);
        triggerVoiceOutput(fallbackMsg);
      }
    },
    [telemetry, selectedLanguage, triggerVoiceOutput]
  );

  // Emergency SOS Broadcast Handler
  const handleTriggerSOS = useCallback(() => {
    triggerHapticBuzz();
    playHUDAlertPing('alert');
    const sosMsg = `[AAPATKALEEN SOS ALERT]: Rahul (Beta) aur Dr. Verma ko aapka pulse (${telemetry.bpm} BPM) aur suraksha sandesh bhej diya gaya hai. Sakhi aapke paas hai, aaram se baith jayein.`;
    setLatestAlert(sosMsg);
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: 'ai',
        text: sosMsg,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        pulseAtMoment: telemetry.bpm,
      },
    ]);
    triggerVoiceOutput(
      `Aapatkaleen alert bhej diya gaya hai. Rahul aur doctor ko aapka pulse ${telemetry.bpm} BPM bhej diya hai. Kripya shanti se baith jayein.`
    );
  }, [telemetry.bpm, triggerVoiceOutput]);

  // Voice Reminder Voice Output
  const handlePlayVoiceReminder = useCallback(
    (text: string) => {
      triggerVoiceOutput(text);
    },
    [triggerVoiceOutput]
  );

  // Toggle Microphone
  const handleToggleMic = () => {
    if (isListening) {
      if (speechRecognizerRef.current) {
        try {
          speechRecognizerRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      selectedLanguage,
      (transcript, isFinal) => {
        if (isFinal && transcript.trim()) {
          setIsListening(false);
          handleSendMessage(transcript.trim(), true);
        }
      },
      (error) => {
        console.warn('Speech recognition error:', error);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );

    if (recognizer) {
      speechRecognizerRef.current = recognizer;
      try {
        recognizer.start();
        setIsListening(true);
        playHUDAlertPing('whisper');
      } catch (err) {
        console.error('Recognition start error:', err);
        setIsListening(false);
      }
    } else {
      const sampleSeniorQueries = [
        'Sakhi, meri aaj ki dawai ka routine batao',
        'Mera pulse aur BP kaisa hai abhi?',
        'Mujhe sukoon bhari saans lene mein madad karo',
        'Kya aaj dhoop mein walk karna theek rahega?',
      ];
      const randomQuery = sampleSeniorQueries[Math.floor(Math.random() * sampleSeniorQueries.length)];
      handleSendMessage(randomQuery, true);
    }
  };

  // Scenario Simulation
  const handleSimulateScenario = (scenario: 'normal' | 'workout' | 'spike' | 'panic' | 'meditation') => {
    triggerHapticBuzz();

    if (scenario === 'normal') {
      setTelemetry((prev) => ({
        ...prev,
        bpm: 72,
        hrv: 55,
        stressLevel: 22,
        status: 'Normal Resting',
        activity: 'Resting',
      }));
      setLatestAlert(undefined);
    } else if (scenario === 'meditation') {
      setTelemetry((prev) => ({
        ...prev,
        bpm: 62,
        hrv: 68,
        stressLevel: 12,
        status: 'Optimal Focus',
        activity: 'Meditation',
      }));
      setLatestAlert('Vitals calmed: Parasympathetic tone active.');
    } else if (scenario === 'workout') {
      setTelemetry((prev) => ({
        ...prev,
        bpm: 128,
        hrv: 35,
        stressLevel: 55,
        status: 'Elevated',
        activity: 'Workout',
      }));
      triggerProactiveAlert('workout_cardio', 128);
    } else if (scenario === 'spike') {
      setTelemetry((prev) => ({
        ...prev,
        bpm: 138,
        hrv: 24,
        stressLevel: 82,
        status: 'Tachycardia Alert',
        activity: 'Stressed',
      }));
      triggerProactiveAlert('tachycardia', 138);
    } else if (scenario === 'panic') {
      setTelemetry((prev) => ({
        ...prev,
        bpm: 155,
        hrv: 18,
        stressLevel: 94,
        status: 'High Stress',
        activity: 'Panic Attack',
      }));
      triggerProactiveAlert('panic_spike', 155);
    }
  };

  const handleManualBpmChange = (newBpm: number) => {
    let status: PulseTelemetry['status'] = 'Normal Resting';
    let stress = Math.min(100, Math.max(10, Math.round((newBpm - 50) * 0.9)));

    if (newBpm > 125) {
      status = 'Tachycardia Alert';
    } else if (newBpm > 95) {
      status = 'Elevated';
    } else if (newBpm < 55) {
      status = 'Bradycardia Alert';
    }

    setTelemetry((prev) => ({
      ...prev,
      bpm: newBpm,
      stressLevel: stress,
      status,
    }));

    if (newBpm >= 125 && (!latestAlert || telemetry.bpm < 125)) {
      triggerProactiveAlert('tachycardia', newBpm);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans p-3 sm:p-6 lg:p-8">
      {/* Universal Device Switcher Frame Header */}
      <DeviceFrame
        currentMode={deviceMode}
        onSelectMode={(mode) => {
          stopSpeech();
          triggerHapticBuzz();
          setDeviceMode(mode);
        }}
        pulseBpm={telemetry.bpm}
      />

      {/* Dynamic Viewport Modes */}
      <main className="flex-1 w-full max-w-6xl mx-auto">
        {deviceMode === 'spects' && (
          <SpectsHUD
            telemetry={telemetry}
            messages={messages}
            isListening={isListening}
            onToggleMic={handleToggleMic}
            activeLanguage={
              SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi'
            }
            onQuickWhisper={(query) => handleSendMessage(query, false)}
            latestAlert={latestAlert}
            isSpeaking={isSpeaking}
            routineState={routineState}
            onTriggerSOS={handleTriggerSOS}
          />
        )}

        {deviceMode === 'watch' && (
          <WatchFace
            telemetry={telemetry}
            messages={messages}
            isListening={isListening}
            onToggleMic={handleToggleMic}
            activeLanguage={
              SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi'
            }
            onOpenBreathing={() => setShowBreathingModal(true)}
            onQuickWhisper={(query) => handleSendMessage(query, false)}
            isSpeaking={isSpeaking}
            latestAlert={latestAlert}
            routineState={routineState}
            onTriggerSOS={handleTriggerSOS}
          />
        )}

        {deviceMode === 'phone' && (
          <PhoneHub
            telemetry={telemetry}
            messages={messages}
            isListening={isListening}
            onToggleMic={handleToggleMic}
            onSendMessage={handleSendMessage}
            selectedLanguage={selectedLanguage}
            onLanguageChange={(newLang) => {
              setSelectedLanguage(newLang);
              stopSpeech();
            }}
            isSpeaking={isSpeaking}
            voiceAudioEnabled={voiceAudioEnabled}
            onToggleVoiceAudio={() => {
              setVoiceAudioEnabled(!voiceAudioEnabled);
              if (voiceAudioEnabled) stopSpeech();
            }}
            onSimulateScenario={handleSimulateScenario}
            onManualBpmChange={handleManualBpmChange}
            alerts={alerts}
            isLoadingAI={isLoadingAI}
            routineState={routineState}
            onUpdateRoutine={setRoutineState}
            onTriggerSOS={handleTriggerSOS}
            onPlayVoiceReminder={handlePlayVoiceReminder}
          />
        )}

        {deviceMode === 'tri-sync' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto mb-4">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Tri-Device Real-Time Sync: Shireenzs Apki Sakhi
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Synchronizes elder medicine reminders, hydration tracking, biometric alerts, and
                loving conversational guidance simultaneously across Spects AR, Watch, and Phone.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              {/* Glasses HUD column */}
              <div className="space-y-4">
                <div className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-400" />
                  1. Spects Smart Glasses AR HUD (Elder Vision)
                </div>
                <SpectsHUD
                  telemetry={telemetry}
                  messages={messages}
                  isListening={isListening}
                  onToggleMic={handleToggleMic}
                  activeLanguage={
                    SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi'
                  }
                  onQuickWhisper={(query) => handleSendMessage(query, false)}
                  latestAlert={latestAlert}
                  isSpeaking={isSpeaking}
                  routineState={routineState}
                  onTriggerSOS={handleTriggerSOS}
                />
              </div>

              {/* Watch Wrist Face column */}
              <div className="space-y-4">
                <div className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-pink-400" />
                  2. Smartwatch Wrist Face (Medicine & SOS)
                </div>
                <WatchFace
                  telemetry={telemetry}
                  messages={messages}
                  isListening={isListening}
                  onToggleMic={handleToggleMic}
                  activeLanguage={
                    SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage)?.name || 'Hindi'
                  }
                  onOpenBreathing={() => setShowBreathingModal(true)}
                  onQuickWhisper={(query) => handleSendMessage(query, false)}
                  isSpeaking={isSpeaking}
                  latestAlert={latestAlert}
                  routineState={routineState}
                  onTriggerSOS={handleTriggerSOS}
                />
              </div>
            </div>

            {/* Phone Hub full controls below */}
            <div className="mt-8 pt-8 border-t border-slate-800 space-y-4">
              <div className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                3. Phone Companion Hub & Daily Sakhi Elder Console
              </div>
              <PhoneHub
                telemetry={telemetry}
                messages={messages}
                isListening={isListening}
                onToggleMic={handleToggleMic}
                onSendMessage={handleSendMessage}
                selectedLanguage={selectedLanguage}
                onLanguageChange={(newLang) => {
                  setSelectedLanguage(newLang);
                  stopSpeech();
                }}
                isSpeaking={isSpeaking}
                voiceAudioEnabled={voiceAudioEnabled}
                onToggleVoiceAudio={() => {
                  setVoiceAudioEnabled(!voiceAudioEnabled);
                  if (voiceAudioEnabled) stopSpeech();
                }}
                onSimulateScenario={handleSimulateScenario}
                onManualBpmChange={handleManualBpmChange}
                alerts={alerts}
                isLoadingAI={isLoadingAI}
                routineState={routineState}
                onUpdateRoutine={setRoutineState}
                onTriggerSOS={handleTriggerSOS}
                onPlayVoiceReminder={handlePlayVoiceReminder}
              />
            </div>
          </div>
        )}
      </main>

      {/* Floating Global Breathing Guide Modal */}
      {showBreathingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md">
            <BreathingGuide
              currentBpm={telemetry.bpm}
              onClose={() => setShowBreathingModal(false)}
              onPacingComplete={() => {
                handleManualBpmChange(Math.max(65, telemetry.bpm - 15));
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
