export type DeviceMode = 'phone' | 'watch' | 'spects' | 'tri-sync';

export interface PulseTelemetry {
  bpm: number;
  hrv: number; // in ms
  stressLevel: number; // 0 - 100%
  spo2: number; // 90 - 100%
  bodyTemp: number; // in Celsius e.g. 36.8
  status: 'Normal Resting' | 'Optimal Focus' | 'Elevated' | 'High Stress' | 'Tachycardia Alert' | 'Bradycardia Alert';
  activity: 'Resting' | 'Walking' | 'Stressed' | 'Workout' | 'Meditation' | 'Panic Attack';
  isConnected: boolean;
  batteryLevel: number;
  deviceModel: string;
  lastUpdated: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai' | 'system';
  text: string;
  timestamp: string;
  language?: string;
  pulseAtMoment?: number;
  isVoiceInput?: boolean;
}

export interface BiometricAlert {
  id: string;
  type: 'warning' | 'alert' | 'info' | 'recovery';
  title: string;
  message: string;
  timestamp: string;
  bpm: number;
  read: boolean;
}

// Senior Citizen Daily Routine & Health Interfaces
export interface MedicineScheduleItem {
  id: string;
  name: string;
  dosage: string;
  time: string;
  instructions: string;
  taken: boolean;
  category: 'morning' | 'afternoon' | 'evening' | 'night';
}

export interface EmergencyContact {
  name: string;
  relation: string;
  phone: string;
}

export interface SeniorRoutineState {
  elderName: string;
  glassesOfWater: number;
  targetGlasses: number;
  lastWaterTime: string;
  morningWalkCompleted: boolean;
  eveningRestCompleted: boolean;
  medicines: MedicineScheduleItem[];
  emergencyContacts: EmergencyContact[];
  seniorModeLargeFont: boolean;
}

export interface SupportedLanguage {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  { code: 'hi-IN', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'ur-PK', name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰' },
  { code: 'en-US', name: 'English (US)', nativeName: 'English', flag: '🇺🇸' },
  { code: 'bn-BD', name: 'Bengali', nativeName: 'বাংলা', flag: '🇧🇩' },
  { code: 'pa-IN', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'mr-IN', name: 'Marathi', nativeName: 'मराठी', flag: '🇮🇳' },
  { code: 'gu-IN', name: 'Gujarati', nativeName: 'ગુજરાતી', flag: '🇮🇳' },
  { code: 'ta-IN', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te-IN', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳' },
  { code: 'ar-SA', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
  { code: 'es-ES', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr-FR', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'de-DE', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'ru-RU', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'zh-CN', name: 'Chinese (Mandarin)', nativeName: '中文', flag: '🇨🇳' },
  { code: 'ja-JP', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
];
