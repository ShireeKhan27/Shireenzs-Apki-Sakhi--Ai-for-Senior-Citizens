import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wind, Play, Pause, CheckCircle2, X } from 'lucide-react';
import { playHUDAlertPing } from '../utils/audio';

interface BreathingGuideProps {
  currentBpm: number;
  onClose?: () => void;
  onPacingComplete?: () => void;
}

export const BreathingGuide: React.FC<BreathingGuideProps> = ({
  currentBpm,
  onClose,
  onPacingComplete,
}) => {
  const [isActive, setIsActive] = useState<boolean>(true);
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [cycleCount, setCycleCount] = useState<number>(0);
  const [secondsLeft, setSecondsLeft] = useState<number>(4);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          // Switch phase
          if (phase === 'Inhale') {
            setPhase('Hold');
            playHUDAlertPing('whisper');
            return 4;
          } else if (phase === 'Hold') {
            setPhase('Exhale');
            playHUDAlertPing('whisper');
            return 4;
          } else if (phase === 'Exhale') {
            setPhase('Rest');
            return 2;
          } else {
            setPhase('Inhale');
            setCycleCount((c) => c + 1);
            playHUDAlertPing('success');
            return 4;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, phase]);

  const getScale = () => {
    if (phase === 'Inhale') return 1.4;
    if (phase === 'Hold') return 1.4;
    if (phase === 'Exhale') return 0.85;
    return 0.85;
  };

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 p-6 border border-cyan-500/30 shadow-2xl backdrop-blur-md">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Wind className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              Biofeedback Pacing Guide
            </h3>
            <p className="text-xs text-slate-400">
              Synced with your pulse wearable ({currentBpm} BPM)
            </p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Animation Stage */}
      <div className="flex flex-col items-center justify-center py-8">
        <div className="relative flex items-center justify-center w-52 h-52">
          {/* Ambient Glow Circles */}
          <motion.div
            animate={{
              scale: isActive ? getScale() * 1.15 : 1,
              opacity: phase === 'Inhale' || phase === 'Hold' ? 0.35 : 0.15,
            }}
            transition={{ duration: phase === 'Hold' || phase === 'Rest' ? 0.2 : 4, ease: 'easeInOut' }}
            className="absolute inset-0 rounded-full bg-cyan-500/20 blur-xl"
          />

          {/* Concentric Guide Ring */}
          <div className="absolute inset-2 rounded-full border border-cyan-500/20 border-dashed animate-spin-slow" />

          {/* Main Breathing Core */}
          <motion.div
            animate={{
              scale: isActive ? getScale() : 1,
            }}
            transition={{
              duration: phase === 'Hold' || phase === 'Rest' ? 0.2 : 4,
              ease: 'easeInOut',
            }}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center shadow-lg transition-colors duration-500 ${
              phase === 'Inhale'
                ? 'bg-gradient-to-tr from-cyan-600 to-teal-400 text-white shadow-cyan-500/40'
                : phase === 'Hold'
                ? 'bg-gradient-to-tr from-teal-500 to-emerald-400 text-white shadow-teal-500/40'
                : phase === 'Exhale'
                ? 'bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white shadow-indigo-500/40'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            <span className="text-xs uppercase tracking-widest font-bold opacity-80">
              {phase}
            </span>
            <span className="text-3xl font-extrabold tracking-tighter">
              {secondsLeft}s
            </span>
          </motion.div>
        </div>

        {/* Phase Guidance text */}
        <p className="mt-4 text-sm font-medium text-slate-300 text-center">
          {phase === 'Inhale' && 'Deep breath through your nose into belly...'}
          {phase === 'Hold' && 'Hold breath comfortably. Soften your shoulders.'}
          {phase === 'Exhale' && 'Gentle, slow release through mouth...'}
          {phase === 'Rest' && 'Pause naturally before next cycle.'}
        </p>

        <div className="mt-2 flex items-center gap-2 text-xs text-cyan-400/80 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-900/50">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Completed Cycles: {cycleCount} • Vagus Nerve Stimulation</span>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center justify-center gap-3 pt-3 border-t border-slate-800/80">
        <button
          onClick={() => setIsActive(!isActive)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-md active:scale-95"
        >
          {isActive ? (
            <>
              <Pause className="w-4 h-4" /> Pause Pacing
            </>
          ) : (
            <>
              <Play className="w-4 h-4" /> Resume Pacing
            </>
          )}
        </button>

        {cycleCount >= 2 && (
          <button
            onClick={() => {
              onPacingComplete?.();
              onClose?.();
            }}
            className="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-semibold text-xs transition-all"
          >
            Pulse Lowered & Recovered
          </button>
        )}
      </div>
    </div>
  );
};
