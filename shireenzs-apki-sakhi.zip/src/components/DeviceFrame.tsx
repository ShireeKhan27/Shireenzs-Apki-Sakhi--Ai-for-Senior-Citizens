import React from 'react';
import { Glasses, Watch, Smartphone, Layers } from 'lucide-react';
import { DeviceMode } from '../types';

interface DeviceFrameProps {
  currentMode: DeviceMode;
  onSelectMode: (mode: DeviceMode) => void;
  pulseBpm: number;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({
  currentMode,
  onSelectMode,
  pulseBpm,
}) => {
  return (
    <div className="w-full max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 p-3 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl backdrop-blur-md">
      {/* Brand & Live Sync Tag */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 via-pink-500 to-amber-400 text-white font-black shadow-lg shadow-rose-500/20 text-base">
          S
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-sm sm:text-base text-white tracking-tight">
              Shireenzs Apki Sakhi
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
              Senior Daily Companion
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Loving AI Guardian for Elders • Glasses, Watch & Phone
          </p>
        </div>
      </div>

      {/* Device Mode Switcher Tabs */}
      <div className="flex items-center p-1 rounded-xl bg-slate-950 border border-slate-800/80">
        <button
          onClick={() => onSelectMode('spects')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'spects'
              ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Glasses className="w-3.5 h-3.5" />
          <span>Spects AR</span>
        </button>

        <button
          onClick={() => onSelectMode('watch')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'watch'
              ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Watch className="w-3.5 h-3.5" />
          <span>Watch</span>
        </button>

        <button
          onClick={() => onSelectMode('phone')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'phone'
              ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Phone Hub</span>
        </button>

        <button
          onClick={() => onSelectMode('tri-sync')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'tri-sync'
              ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
          title="View all 3 synchronized devices together"
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Tri-Sync Ecosystem</span>
          <span className="sm:hidden">Tri-Sync</span>
        </button>
      </div>
    </div>
  );
};
