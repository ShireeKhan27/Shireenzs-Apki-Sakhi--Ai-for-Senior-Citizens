import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Pill,
  Droplets,
  Sun,
  Moon,
  Volume2,
  PhoneCall,
  ShieldAlert,
  Sparkles,
  CheckCircle,
  Clock,
  UserCheck,
  AlertCircle,
  MessageCircleHeart,
  Plus,
  Compass,
} from 'lucide-react';
import { PulseTelemetry, MedicineScheduleItem, SeniorRoutineState } from '../types';
import { triggerHapticBuzz, playHUDAlertPing } from '../utils/audio';

interface SeniorCompanionHubProps {
  telemetry: PulseTelemetry;
  routineState: SeniorRoutineState;
  onUpdateRoutine: (updater: (prev: SeniorRoutineState) => SeniorRoutineState) => void;
  onTalkWithSakhi: (prompt: string) => void;
  onTriggerSOS: () => void;
  isSpeaking: boolean;
  onPlayVoiceReminder: (text: string) => void;
}

export const SeniorCompanionHub: React.FC<SeniorCompanionHubProps> = ({
  telemetry,
  routineState,
  onUpdateRoutine,
  onTalkWithSakhi,
  onTriggerSOS,
  isSpeaking,
  onPlayVoiceReminder,
}) => {
  const [sosActivated, setSosActivated] = useState(false);
  const [showAddPill, setShowAddPill] = useState(false);
  const [newPillName, setNewPillName] = useState('');
  const [newPillTime, setNewPillTime] = useState('02:00 PM');
  const [newPillDosage, setNewPillDosage] = useState('1 Tablet');

  const getTimeGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return { greeting: 'Suprabhat (Good Morning)', icon: Sun, color: 'text-amber-400' };
    if (hour < 17) return { greeting: 'Shubh Dopahar (Good Afternoon)', icon: Sun, color: 'text-amber-300' };
    if (hour < 21) return { greeting: 'Shubh Sandhya (Good Evening)', icon: Moon, color: 'text-indigo-300' };
    return { greeting: 'Shubh Ratri (Peaceful Night)', icon: Moon, color: 'text-purple-300' };
  };

  const { greeting, icon: TimeIcon, color: timeColor } = getTimeGreeting();

  const handleToggleMedicine = (id: string) => {
    triggerHapticBuzz();
    playHUDAlertPing('success');
    onUpdateRoutine((prev) => ({
      ...prev,
      medicines: prev.medicines.map((m) => (m.id === id ? { ...m, taken: !m.taken } : m)),
    }));
  };

  const handleDrinkWater = () => {
    triggerHapticBuzz();
    playHUDAlertPing('whisper');
    const newCount = Math.min(12, routineState.glassesOfWater + 1);
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    onUpdateRoutine((prev) => ({
      ...prev,
      glassesOfWater: newCount,
      lastWaterTime: nowTime,
    }));
    onPlayVoiceReminder(
      `Bahut achhe! Aapne ${newCount} glass paani pee liya hai. Sharir ko hydration milne se aapka dil aur BP dono behtar rahenge.`
    );
  };

  const handleSOS = () => {
    triggerHapticBuzz();
    playHUDAlertPing('alert');
    setSosActivated(true);
    onTriggerSOS();
  };

  const handleAddMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPillName.trim()) return;
    const newMed: MedicineScheduleItem = {
      id: Date.now().toString(),
      name: newPillName.trim(),
      dosage: newPillDosage,
      time: newPillTime,
      instructions: 'After meal with water',
      taken: false,
      category: 'afternoon',
    };
    onUpdateRoutine((prev) => ({
      ...prev,
      medicines: [...prev.medicines, newMed],
    }));
    setNewPillName('');
    setShowAddPill(false);
  };

  const largeFont = routineState.seniorModeLargeFont;

  return (
    <div className={`space-y-6 ${largeFont ? 'text-lg' : 'text-base'}`}>
      {/* Warm Loving Greeting Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-rose-950/70 via-slate-900 to-teal-950/70 border-2 border-rose-500/30 p-5 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <MessageCircleHeart className="w-4 h-4 text-rose-400" />
                Shireenzs Apki Sakhi • Elder Care Companion
              </span>
              {isSpeaking && (
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono animate-pulse">
                  <Volume2 className="w-4 h-4" /> Sakhi bol rahi hain...
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
              <TimeIcon className={`w-7 h-7 ${timeColor}`} />
              <span>
                {greeting}, <span className="text-rose-300">{routineState.elderName}!</span>
              </span>
            </h2>

            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Main hoon <strong className="text-rose-200">Shireenzs Apki Sakhi</strong>. Aapka pulse{' '}
              <span className="font-bold text-cyan-300">{telemetry.bpm} BPM</span> par sthir hai.
              Aaj ka din khushi, sukoon aur achhi sehat se bhara ho.
            </p>
          </div>

          {/* Quick Voice Talk Hero Button */}
          <button
            onClick={() =>
              onTalkWithSakhi(
                'Namaste Sakhi! Aaj mera swasthya aur routine kaisa hai? Mujhse thodi baat karein.'
              )
            }
            className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 hover:to-pink-500 text-white font-bold shadow-lg shadow-rose-500/30 flex items-center justify-center gap-3 transition-all transform active:scale-95 cursor-pointer"
          >
            <MessageCircleHeart className="w-6 h-6" />
            <div className="text-left">
              <div className="text-sm sm:text-base font-extrabold">Sakhi Se Baat Karein</div>
              <div className="text-[11px] text-rose-100 font-normal">Tap to speak or listen</div>
            </div>
          </button>
        </div>

        {/* Quick Conversation Starter Chips */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap gap-2.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider self-center mr-1">
            Sakhi se puchein:
          </span>
          {[
            '🌸 Ek pyari si prerak baat sunao (Inspiring thought)',
            '💊 Meri aaj ki dawai ka routine batao (Medicine schedule)',
            '❤️ Mera dil aur stress kaisa hai? (Vitals check)',
            '🧘‍♀️ Sukoon bhari saans lene mein madad karo (Calm breathing)',
            '☕ Shaam ki chai ke baad halki baat karein (Friendly talk)',
          ].map((prompt, i) => (
            <button
              key={i}
              onClick={() => onTalkWithSakhi(prompt)}
              className="px-3.5 py-2 rounded-xl bg-slate-850 hover:bg-rose-950/60 border border-slate-700/80 hover:border-rose-500/40 text-xs sm:text-sm text-slate-200 hover:text-white transition-all text-left"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Medicine Pill Guardian + Water Hydration Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Medicine / Pill Guardian */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base sm:text-lg">
                    Dawai Ka Samay (Medicine Guardian)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Timely prescriptions • Audio chime reminder
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowAddPill(!showAddPill)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1"
                title="Add medicine"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Add</span>
              </button>
            </div>

            {/* Add Pill Form */}
            {showAddPill && (
              <form onSubmit={handleAddMedicine} className="mt-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="font-bold text-xs text-amber-300 uppercase">Add New Medicine / Tablet</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Medicine name (e.g. BP Tab)"
                    value={newPillName}
                    onChange={(e) => setNewPillName(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    required
                  />
                  <input
                    type="text"
                    placeholder="Dosage (e.g. 1 Tab)"
                    value={newPillDosage}
                    onChange={(e) => setNewPillDosage(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Time (e.g. 02:00 PM)"
                    value={newPillTime}
                    onChange={(e) => setNewPillTime(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddPill(false)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400 text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
                  >
                    Save Medicine
                  </button>
                </div>
              </form>
            )}

            {/* Medicine List */}
            <div className="mt-4 space-y-3 max-h-72 overflow-y-auto pr-1 custom-scrollbar">
              {routineState.medicines.map((med) => (
                <div
                  key={med.id}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    med.taken
                      ? 'bg-slate-950/60 border-emerald-500/30 opacity-75'
                      : 'bg-slate-950 border-slate-800 hover:border-amber-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggleMedicine(med.id)}
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                        med.taken
                          ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                          : 'border-2 border-slate-600 hover:border-amber-400 text-transparent'
                      }`}
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-bold text-sm sm:text-base ${
                            med.taken ? 'line-through text-slate-400' : 'text-white'
                          }`}
                        >
                          {med.name}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono">
                          {med.dosage}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3 text-cyan-400" />
                          {med.time}
                        </span>
                        <span>• {med.instructions}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      onPlayVoiceReminder(
                        `Reminder: Kripya ${med.name}, ${med.dosage} samay par lein. ${med.instructions}.`
                      )
                    }
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-400 border border-slate-700/80"
                    title="Speak reminder"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>
              {routineState.medicines.filter((m) => m.taken).length} of{' '}
              {routineState.medicines.length} medicines taken today
            </span>
            <span className="text-emerald-400 font-bold">Automatic sync to Watch & Spects</span>
          </div>
        </div>

        {/* Water Hydration & Daily Senior Health Habits */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base sm:text-lg">
                    Paani Ka Niyam (Daily Hydration)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Stay fresh & hydrated • Gentle reminders
                  </p>
                </div>
              </div>

              <span className="text-xs font-mono font-bold text-cyan-300 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20">
                Target: {routineState.targetGlasses} Glasses
              </span>
            </div>

            {/* Big Water Progress Meter */}
            <div className="mt-5 p-5 rounded-2xl bg-slate-950 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-center sm:text-left">
                <div className="text-4xl font-black text-cyan-400 font-mono">
                  {routineState.glassesOfWater}{' '}
                  <span className="text-lg font-bold text-slate-400">
                    / {routineState.targetGlasses} Glasses
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Last water log: <strong className="text-slate-200">{routineState.lastWaterTime}</strong>
                </p>
              </div>

              <button
                onClick={handleDrinkWater}
                className="px-5 py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
              >
                <Droplets className="w-5 h-5" />
                <span>+1 Glass Paani Piya</span>
              </button>
            </div>

            {/* Daily Elder Wellness Habits */}
            <div className="mt-5 space-y-2.5">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Swasthya Aadatein (Daily Wellness Habits)
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    triggerHapticBuzz();
                    onUpdateRoutine((prev) => ({
                      ...prev,
                      morningWalkCompleted: !prev.morningWalkCompleted,
                    }));
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    routineState.morningWalkCompleted
                      ? 'bg-teal-950/40 border-teal-500/40 text-teal-200'
                      : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Sun className="w-4 h-4 text-amber-400" />
                    {routineState.morningWalkCompleted && <CheckCircle className="w-4 h-4 text-teal-400" />}
                  </div>
                  <div className="font-bold text-sm mt-1">Halki Subah Walk</div>
                  <div className="text-[11px] text-slate-400">10 mins fresh air</div>
                </button>

                <button
                  onClick={() => {
                    triggerHapticBuzz();
                    onUpdateRoutine((prev) => ({
                      ...prev,
                      eveningRestCompleted: !prev.eveningRestCompleted,
                    }));
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    routineState.eveningRestCompleted
                      ? 'bg-purple-950/40 border-purple-500/40 text-purple-200'
                      : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Moon className="w-4 h-4 text-purple-400" />
                    {routineState.eveningRestCompleted && <CheckCircle className="w-4 h-4 text-purple-400" />}
                  </div>
                  <div className="font-bold text-sm mt-1">Shaam Ka Vishram</div>
                  <div className="text-[11px] text-slate-400">Quiet soothing rest</div>
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Hydration status: Healthy Kidney & Heart Care</span>
            <span className="text-cyan-400 font-bold">Real-time sync</span>
          </div>
        </div>
      </div>

      {/* Senior Safety & Emergency SOS Alert Hub */}
      <div className="rounded-3xl bg-slate-900/90 border-2 border-red-500/40 p-5 sm:p-7 shadow-2xl backdrop-blur-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-400" />
                Aapatkaleen Suraksha (Senior Emergency SOS)
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-extrabold text-white">
              Emergency & Family Connect
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Pressing this alerts your pre-saved family contacts with your current heart rate ({telemetry.bpm} BPM) and location.
            </p>
          </div>

          <button
            onClick={handleSOS}
            className={`w-full sm:w-auto px-8 py-4 rounded-2xl font-black text-lg transition-all shadow-xl flex items-center justify-center gap-3 cursor-pointer ${
              sosActivated
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white active:scale-95 shadow-red-600/30'
            }`}
          >
            <ShieldAlert className="w-6 h-6" />
            <span>{sosActivated ? 'SOS SENT TO FAMILY' : 'EMERGENCY SOS'}</span>
          </button>
        </div>

        {/* Family Contacts Preview */}
        <div className="mt-5 pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {routineState.emergencyContacts.map((contact, i) => (
            <div
              key={i}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between"
            >
              <div>
                <div className="font-bold text-white text-sm">{contact.name}</div>
                <div className="text-xs text-rose-300 font-medium">{contact.relation}</div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">{contact.phone}</div>
              </div>
              <a
                href={`tel:${contact.phone}`}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-emerald-600 hover:text-white text-emerald-400 transition-all"
                title="Call contact"
              >
                <PhoneCall className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>

        {sosActivated && (
          <div className="mt-4 p-4 rounded-2xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs sm:text-sm flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400" />
              <span>
                SOS Alert broadcasted: Family contacts notified with live vitals ({telemetry.bpm} BPM). Apki Sakhi recommends sitting down comfortably.
              </span>
            </div>
            <button
              onClick={() => setSosActivated(false)}
              className="px-3 py-1 rounded-xl bg-slate-800 text-white text-xs font-bold"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
