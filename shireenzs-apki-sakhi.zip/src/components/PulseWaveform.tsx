import React, { useEffect, useRef } from 'react';

interface PulseWaveformProps {
  bpm: number;
  stressLevel: number;
  height?: number;
  accentColor?: string;
  isCompact?: boolean;
}

export const PulseWaveform: React.FC<PulseWaveformProps> = ({
  bpm,
  stressLevel,
  height = 96,
  accentColor,
  isCompact = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let x = 0;
    const points: number[] = [];

    // Scale canvas for sharp high-DPI displays
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Speed scaled by heart rate
    // 60 BPM = 1 beat/sec; 120 BPM = 2 beats/sec
    let beatProgress = 0;

    const render = () => {
      // Calculate beat cycle (0 to 1)
      const beatsPerSecond = Math.max(40, Math.min(180, bpm)) / 60;
      beatProgress += (beatsPerSecond * 0.016); // ~60fps
      const cycle = beatProgress % 1;

      // Realistic PPG / ECG combined pulse shape
      let yOffset = 0;
      if (cycle >= 0.15 && cycle < 0.2) {
        // P-wave
        yOffset = -Math.sin((cycle - 0.15) * Math.PI / 0.05) * 8;
      } else if (cycle >= 0.22 && cycle < 0.25) {
        // Q-dip
        yOffset = 5;
      } else if (cycle >= 0.25 && cycle < 0.32) {
        // R-peak (sharp spike)
        const peakProg = (cycle - 0.25) / 0.07;
        const spikeMultiplier = stressLevel > 60 ? 1.3 : 1.0;
        yOffset = -Math.sin(peakProg * Math.PI) * (height * 0.42 * spikeMultiplier);
      } else if (cycle >= 0.32 && cycle < 0.36) {
        // S-dip
        yOffset = 8;
      } else if (cycle >= 0.45 && cycle < 0.65) {
        // T-wave (dicrotic repolarization)
        yOffset = -Math.sin((cycle - 0.45) * Math.PI / 0.20) * 12;
      } else {
        // Baseline noise
        yOffset = (Math.random() - 0.5) * 1.5;
      }

      const baseline = height / 2;
      const currentY = baseline + yOffset;

      points.push(currentY);
      if (points.length > width) {
        points.shift();
      }

      // Clear canvas with subtle trail
      ctx.clearRect(0, 0, width, height);

      // Draw subtle background medical grid
      if (!isCompact) {
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.4)';
        ctx.lineWidth = 1;
        const gridSize = 16;
        for (let gx = 0; gx < width; gx += gridSize) {
          ctx.beginPath();
          ctx.moveTo(gx, 0);
          ctx.lineTo(gx, height);
          ctx.stroke();
        }
        for (let gy = 0; gy < height; gy += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, gy);
          ctx.lineTo(width, gy);
          ctx.stroke();
        }
      }

      // Determine waveform color
      let strokeStyle = accentColor;
      if (!strokeStyle) {
        if (bpm > 115 || stressLevel > 70) {
          strokeStyle = '#f43f5e'; // Rose / high alert
        } else if (bpm > 95 || stressLevel > 45) {
          strokeStyle = '#f59e0b'; // Amber / elevated
        } else {
          strokeStyle = '#06b6d4'; // Cyan / calm steady
        }
      }

      // Draw glowing pulse wave
      ctx.shadowBlur = 8;
      ctx.shadowColor = strokeStyle;
      ctx.strokeStyle = strokeStyle;
      ctx.lineWidth = isCompact ? 1.75 : 2.2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.beginPath();
      for (let i = 0; i < points.length; i++) {
        const px = i;
        const py = points[i];
        if (i === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.stroke();

      // Lead blip point
      if (points.length > 0) {
        const lastX = points.length - 1;
        const lastY = points[points.length - 1];
        ctx.shadowBlur = 12;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(lastX, lastY, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.shadowBlur = 0;
      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [bpm, stressLevel, height, accentColor, isCompact]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl bg-slate-950/80 border border-slate-800/80">
      <canvas
        ref={canvasRef}
        className="w-full block"
        style={{ height: `${height}px` }}
      />
    </div>
  );
};
