import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Glasses,
  Heart,
  Volume2,
  Mic,
  Activity,
  ShieldAlert,
  BatteryCharging,
  Wifi,
  Sparkles,
  Pill,
  Droplets,
} from 'lucide-react';
import { PulseTelemetry, ChatMessage, SeniorRoutineState } from '../types';
import { PulseWaveform } from './PulseWaveform';
import { triggerHapticBuzz, playHUDAlertPing } from '../utils/audio';

interface SpectsHUDProps {
  telemetry: PulseTelemetry;
  messages: ChatMessage[];
  isListening: boolean;
  onToggleMic: () => void;
  activeLanguage: string;
  onQuickWhisper: (query: string) => void;
  latestAlert?: string;
  isSpeaking: boolean;
  routineState?: SeniorRoutineState;
  onTriggerSOS?: () => void;
}

export const SpectsHUD: React.FC<SpectsHUDProps> = ({
  telemetry,
  messages,
  isListening,
  onToggleMic,
  activeLanguage,
  onQuickWhisper,
  latestAlert,
  isSpeaking,
  routineState,
  onTriggerSOS,
}) => {
  const [hudBrightness, setHudBrightness] = useState<number>(90);
  const [isTempleTapped, setIsTempleTapped] = useState<boolean>(false);

  const handleTempleTap = () => {
    setIsTempleTapped(true);
    triggerHapticBuzz();
    playHUDAlertPing('whisper');
    onToggleMic();
    setTimeout(() => setIsTempleTapped(false), 500);
  };

  const lastAiMessage = [...messages].reverse().find((m) => m.sender === 'ai');
  const lastUserMessage = [...messages].reverse().find((m) => m.sender === 'user');
  const nextMedicine = routineState?.medicines.find((m) => !m.taken);

  return (
    <div className="relative w-full max-w-4xl mx-auto rounded-3xl p-1 bg-gradient-to-b from-slate-700/60 via-slate-900 to-slate-950 shadow-2xl border border-slate-700/60 overflow-hidden">
      {/* Smart Glasses Frame Border Simulation */}
      <div className="relative rounded-[22px] bg-slate-950 p-6 sm:p-8 min-h-[460px] flex flex-col justify-between overflow-hidden">
        {/* AR Optical Tint Overlay & Vignette */}
        <div
          className="absolute inset-0 bg-gradient-to-tr from-cyan-950/20 via-slate-950/90 to-rose-950/20 pointer-events-none"
          style={{ opacity: hudBrightness / 100 }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-slate-950/40 to-slate-950/95 pointer-events-none" />

        {/* Top Peripheral AR Bar: Connectivity, Wearable Sync & Battery */}
        <div className="relative z-10 flex items-center justify-between pb-4 border-b border-slate-800/80">
          {/* Left Peripheral: Smart Glasses Stem Status */}
          <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
            <div className="flex items-center gap-1 text-rose-400">
              <Glasses className="w-4 h-4" />
              <span className="font-bold">SPECTS AR • SAKHI HUD</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="flex items-center gap-1 text-emerald-400">
              <Wifi className="w-3.5 h-3.5" />
              <span>RING-BT</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="flex items-center gap-1 text-cyan-400">
              <BatteryCharging className="w-3.5 h-3.5" />
              <span>{telemetry.batteryLevel}%</span>
            </div>
          </div>

          {/* Right Peripheral: Live Pulse HUD Glance */}
          <div className="flex items-center gap-4 bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-2xl border border-rose-500/30 shadow-lg">
            <div className="flex items-center gap-2">
              <motion.div
                animate={{ scale: [1, 1.25, 1] }}
                transition={{
                  repeat: Infinity,
                  duration: 60 / Math.max(40, telemetry.bpm),
                  ease: 'easeInOut',
                }}
              >
                <Heart
                  className={`w-5 h-5 ${
                    telemetry.bpm > 115
                      ? 'text-rose-500 fill-rose-500'
                      : telemetry.bpm > 95
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-rose-400 fill-rose-400'
                  }`}
                />
              </motion.div>
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black tracking-tight text-white font-mono">
                    {telemetry.bpm}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">BPM</span>
                </div>
                <div className="text-[10px] text-rose-300 font-mono flex items-center gap-1">
                  <span>HRV {telemetry.hrv}ms</span>
                  <span>•</span>
                  <span>O₂ {telemetry.spo2}%</span>
                </div>
              </div>
            </div>

            <div className="w-24 hidden sm:block">
              <PulseWaveform bpm={telemetry.bpm} stressLevel={telemetry.stressLevel} height={38} isCompact />
            </div>
          </div>
        </div>

        {/* Center Optical Reticle & Audio Whisper Subtitle Screen */}
        <div className="relative z-10 my-auto py-4 flex flex-col items-center text-center max-w-2xl mx-auto w-full">
          {/* Subtle Reticle Target */}
          <div className="w-14 h-14 rounded-full border border-rose-500/20 flex items-center justify-center mb-3 relative">
            <div className="w-2 h-2 rounded-full bg-rose-400/80" />
            <div className="absolute top-0 w-2 h-[1px] bg-rose-400" />
            <div className="absolute bottom-0 w-2 h-[1px] bg-rose-400" />
            <div className="absolute left-0 w-[1px] h-2 bg-rose-400" />
            <div className="absolute right-0 w-[1px] h-2 bg-rose-400" />
          </div>

          {/* Elder Glance Ticker in Spects Lens */}
          {nextMedicine && (
            <div className="mb-3 px-4 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-mono flex items-center gap-2">
              <Pill className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>
                AR REMINDER: Next medicine due at {nextMedicine.time} — {nextMedicine.name} ({nextMedicine.dosage})
              </span>
            </div>
          )}

          {/* Active Audio / Voice State Indicator */}
          <div className="flex items-center gap-2 mb-3">
            {isListening ? (
              <motion.span
                animate={{ opacity: [0.6, 1, 0.6] }}
                transition={{ repeat: Infinity, duration: 1.2 }}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 text-xs font-mono font-medium border border-rose-500/30"
              >
                <Mic className="w-3.5 h-3.5 animate-pulse" />
                SPECT MIC ACTIVE • LISTENING ANY LANGUAGE
              </motion.span>
            ) : isSpeaking ? (
              <motion.span
                animate={{ scale: [0.98, 1.02, 0.98] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-mono font-medium border border-rose-500/30"
              >
                <Volume2 className="w-3.5 h-3.5" />
                AUDIO WHISPERING VIA SPECT STEM • {activeLanguage}
              </motion.span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 text-slate-300 text-xs font-mono border border-slate-700">
                <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                SHIREENZS APKI SAKHI STANDBY • TAP TEMPLE OR SPEAK
              </span>
            )}
          </div>

          {/* Real-time Subtitle & Transcription HUD Box */}
          <div className="w-full bg-slate-950/80 backdrop-blur-md rounded-2xl p-5 border border-rose-500/30 shadow-xl relative overflow-hidden text-left">
            <div className="absolute top-2 right-3 text-[10px] font-mono text-rose-400/70 uppercase">
              HUD Subtitle Lens
            </div>

            {lastUserMessage && (
              <div className="mb-2">
                <span className="text-[10px] font-mono uppercase text-slate-400 block mb-0.5">
                  Aapne Kaha (You Spoke):
                </span>
                <p className="text-sm font-medium text-slate-300 italic">
                  "{lastUserMessage.text}"
                </p>
              </div>
            )}

            <div className="mt-2">
              <span className="text-[10px] font-mono uppercase text-rose-400 block mb-0.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-rose-400" />
                Shireenzs Apki Sakhi Whisper:
              </span>
              <p className="text-base sm:text-lg font-semibold text-white leading-relaxed">
                {lastAiMessage
                  ? lastAiMessage.text
                  : `Namaste! Main aapki Sakhi hoon. Aapka pulse ${telemetry.bpm} BPM hai. Chashme ke temple par tap karke baat karein.`}
              </p>
            </div>

            {/* Proactive Pulse Alert Overlay if triggered */}
            {latestAlert && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-3 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs text-left flex items-start gap-2.5"
              >
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-amber-300">Biometric Intercept:</span>
                  <span>{latestAlert}</span>
                </div>
              </motion.div>
            )}
          </div>

          {/* Quick HUD Gaze Directives */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
            <button
              onClick={() => onQuickWhisper('Sakhi, meri aaj ki dawai ka routine batao')}
              className="px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-rose-950/60 text-rose-300 border border-rose-500/20 text-xs font-mono transition-all hover:scale-105"
            >
              "Dawai ka routine batao"
            </button>
            <button
              onClick={() => onQuickWhisper('Mera pulse aur BP kaisa hai abhi?')}
              className="px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-rose-950/60 text-rose-300 border border-rose-500/20 text-xs font-mono transition-all hover:scale-105"
            >
              "Mera pulse kaisa hai?"
            </button>
            <button
              onClick={() => onQuickWhisper('Sukoon bhari saans lene mein madad karo')}
              className="px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-rose-950/60 text-rose-300 border border-rose-500/20 text-xs font-mono transition-all hover:scale-105"
            >
              "Sukoon bhari saans guide"
            </button>
          </div>
        </div>

        {/* HUD Lower Bar: Spects Controls & Simulated Temple Tap */}
        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800/80">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-rose-400" />
            <span>Voice Language:</span>
            <span className="text-rose-300 font-bold">{activeLanguage}</span>
          </div>

          {/* Interactive Spects Temple Touch Trigger & Emergency SOS */}
          <div className="flex items-center gap-3">
            {onTriggerSOS && (
              <button
                onClick={onTriggerSOS}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs transition-all shadow-md"
                title="Trigger Emergency SOS to Family"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>SOS Family Alert</span>
              </button>
            )}

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleTempleTap}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs transition-all shadow-lg cursor-pointer ${
                isTempleTapped || isListening
                  ? 'bg-rose-500 text-white shadow-rose-500/40 ring-4 ring-rose-500/20'
                  : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/30'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>{isListening ? 'Stop Listening' : 'Tap Temple to Talk to Sakhi'}</span>
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
};
