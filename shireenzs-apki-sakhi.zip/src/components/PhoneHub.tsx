import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Activity,
  Mic,
  Send,
  Volume2,
  VolumeX,
  Wind,
  ShieldAlert,
  Globe,
  Radio,
  Sliders,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Info,
  Pill,
  MessageCircleHeart,
  Droplets,
  Type,
} from 'lucide-react';
import {
  PulseTelemetry,
  ChatMessage,
  SUPPORTED_LANGUAGES,
  BiometricAlert,
  SeniorRoutineState,
} from '../types';
import { PulseWaveform } from './PulseWaveform';
import { BreathingGuide } from './BreathingGuide';
import { SeniorCompanionHub } from './SeniorCompanionHub';
import { triggerHapticBuzz, playHUDAlertPing } from '../utils/audio';

interface PhoneHubProps {
  telemetry: PulseTelemetry;
  messages: ChatMessage[];
  isListening: boolean;
  onToggleMic: () => void;
  onSendMessage: (text: string) => void;
  selectedLanguage: string;
  onLanguageChange: (langCode: string) => void;
  isSpeaking: boolean;
  voiceAudioEnabled: boolean;
  onToggleVoiceAudio: () => void;
  onSimulateScenario: (scenario: 'normal' | 'workout' | 'spike' | 'panic' | 'meditation') => void;
  onManualBpmChange: (newBpm: number) => void;
  alerts: BiometricAlert[];
  isLoadingAI: boolean;
  routineState: SeniorRoutineState;
  onUpdateRoutine: (updater: (prev: SeniorRoutineState) => SeniorRoutineState) => void;
  onTriggerSOS: () => void;
  onPlayVoiceReminder: (text: string) => void;
}

export const PhoneHub: React.FC<PhoneHubProps> = ({
  telemetry,
  messages,
  isListening,
  onToggleMic,
  onSendMessage,
  selectedLanguage,
  onLanguageChange,
  isSpeaking,
  voiceAudioEnabled,
  onToggleVoiceAudio,
  onSimulateScenario,
  onManualBpmChange,
  alerts,
  isLoadingAI,
  routineState,
  onUpdateRoutine,
  onTriggerSOS,
  onPlayVoiceReminder,
}) => {
  const [inputText, setInputText] = useState('');
  const [showBreathingModal, setShowBreathingModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'companion' | 'chat' | 'telemetry' | 'alerts'>('companion');
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (activeTab === 'chat') {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoadingAI, activeTab]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const selectedLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage) || SUPPORTED_LANGUAGES[0];

  const toggleLargeFont = () => {
    triggerHapticBuzz();
    onUpdateRoutine((prev) => ({
      ...prev,
      seniorModeLargeFont: !prev.seniorModeLargeFont,
    }));
  };

  return (
    <div className={`w-full max-w-4xl mx-auto space-y-6 ${routineState.seniorModeLargeFont ? 'text-lg' : 'text-base'}`}>
      {/* Top Wearable Telemetry & Senior Status Card */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md relative overflow-hidden">
        {/* Glow ambient background */}
        <div
          className={`absolute -top-24 -right-24 w-72 h-72 rounded-full blur-3xl opacity-20 pointer-events-none transition-colors duration-700 ${
            telemetry.bpm > 115 ? 'bg-rose-500' : telemetry.bpm > 95 ? 'bg-amber-500' : 'bg-rose-400'
          }`}
        />

        {/* Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping absolute inset-0 opacity-75" />
              <div className="w-3 h-3 rounded-full bg-emerald-500 relative z-10" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                <span>{telemetry.deviceModel}</span>
                <span className="text-rose-400 text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/20">
                  Sakhi Synced
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Continuous Bio-Feedback on Glasses, Watch & Phone
              </p>
            </div>
          </div>

          {/* Quick Accessibility & Audio Actions */}
          <div className="flex items-center gap-2">
            {/* Senior Large Font Button */}
            <button
              onClick={toggleLargeFont}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                routineState.seniorModeLargeFont
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
              title="Toggle Large Text for Senior Readability"
            >
              <Type className="w-3.5 h-3.5" />
              <span>Bade Akshar (Large Font)</span>
            </button>

            {/* Breathing Pacer */}
            <button
              onClick={() => setShowBreathingModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-semibold transition-all"
            >
              <Wind className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sukoon Saans</span>
            </button>

            {/* Audio Voice Toggle */}
            <button
              onClick={onToggleVoiceAudio}
              className={`p-2 rounded-xl border text-xs font-semibold transition-all ${
                voiceAudioEnabled
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
              title={voiceAudioEnabled ? 'Voice output enabled' : 'Voice output muted'}
            >
              {voiceAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Live Vitals Glance Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 py-4">
          {/* Heart Rate BPM */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">PULSE RATE</span>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{
                  repeat: Infinity,
                  duration: 60 / Math.max(40, telemetry.bpm),
                  ease: 'easeInOut',
                }}
              >
                <Heart
                  className={`w-4 h-4 ${
                    telemetry.bpm > 115
                      ? 'text-rose-500 fill-rose-500'
                      : telemetry.bpm > 95
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-rose-400 fill-rose-400'
                  }`}
                />
              </motion.div>
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white">
                  {telemetry.bpm}
                </span>
                <span className="text-xs font-bold text-slate-400">BPM</span>
              </div>
              <span
                className={`inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  telemetry.bpm > 115
                    ? 'bg-rose-500/20 text-rose-300'
                    : telemetry.bpm > 95
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-emerald-500/20 text-emerald-300'
                }`}
              >
                {telemetry.status}
              </span>
            </div>
          </div>

          {/* HRV */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">VARIABILITY (HRV)</span>
              <Activity className="w-4 h-4 text-teal-400" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black font-mono tracking-tight text-white">
                  {telemetry.hrv}
                </span>
                <span className="text-xs font-bold text-slate-400">ms</span>
              </div>
              <span className="inline-block mt-1 text-[10px] font-semibold text-slate-400">
                {telemetry.hrv > 50 ? 'Balanced Heart Rhythm' : 'Requires Rest'}
              </span>
            </div>
          </div>

          {/* Next Medicine */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">AGLI DAWAI (MEDICINE)</span>
              <Pill className="w-4 h-4 text-amber-400" />
            </div>
            <div className="my-1">
              {routineState.medicines.find((m) => !m.taken) ? (
                <>
                  <div className="text-sm font-bold text-amber-300 truncate">
                    {routineState.medicines.find((m) => !m.taken)?.name}
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    Due at {routineState.medicines.find((m) => !m.taken)?.time}
                  </div>
                </>
              ) : (
                <div className="text-xs text-emerald-400 font-bold mt-1">
                  Sabhi dawai le li gayi hain!
                </div>
              )}
            </div>
            <button
              onClick={() => setActiveTab('companion')}
              className="text-[11px] text-amber-400 hover:underline text-left font-bold"
            >
              View timetable →
            </button>
          </div>

          {/* Water Meter Glance */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">PAANI (HYDRATION)</span>
              <Droplets className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="my-2">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black font-mono tracking-tight text-cyan-400">
                  {routineState.glassesOfWater}
                </span>
                <span className="text-xs font-bold text-slate-400">/ 8 Glasses</span>
              </div>
              <span className="inline-block mt-1 text-[10px] font-semibold text-slate-400">
                Last: {routineState.lastWaterTime}
              </span>
            </div>
          </div>
        </div>

        {/* Live Continuous Waveform */}
        <div className="mt-1 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-1">
            <span className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-rose-400" />
              LIVE PPG CONTINUOUS PULSE WAVEFORM
            </span>
            <span>Wearable Pulse Band • {telemetry.bpm} BPM</span>
          </div>
          <PulseWaveform bpm={telemetry.bpm} stressLevel={telemetry.stressLevel} height={68} />
        </div>
      </div>

      {/* Navigation Tabs Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('companion')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'companion'
                ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageCircleHeart className="w-4 h-4" />
            <span>🌸 Daily Companion (Sakhi)</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-slate-800 text-cyan-300 shadow-md border border-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>💬 Voice & Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('telemetry')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'telemetry'
                ? 'bg-slate-800 text-white shadow-md border border-slate-700'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sliders className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Wearable Test Scenarios</span>
            <span className="sm:hidden">Test</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'alerts'
                ? 'bg-slate-800 text-red-300 shadow-md border border-red-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-red-400" />
            <span>Alerts ({alerts.length})</span>
          </button>
        </div>

        {/* Language Selector */}
        <div className="flex items-center gap-2 px-2">
          <Globe className="w-4 h-4 text-rose-400" />
          <select
            value={selectedLanguage}
            onChange={(e) => onLanguageChange(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 font-medium focus:outline-none focus:border-rose-500 cursor-pointer"
          >
            {SUPPORTED_LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.flag} {lang.name} ({lang.nativeName})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tab 1: Senior Companion Hub (Daily Companion View) */}
      {activeTab === 'companion' && (
        <SeniorCompanionHub
          telemetry={telemetry}
          routineState={routineState}
          onUpdateRoutine={onUpdateRoutine}
          onTalkWithSakhi={(prompt) => {
            setActiveTab('chat');
            onSendMessage(prompt);
          }}
          onTriggerSOS={onTriggerSOS}
          isSpeaking={isSpeaking}
          onPlayVoiceReminder={onPlayVoiceReminder}
        />
      )}

      {/* Tab 2: Multilingual Voice & AI Chat Console */}
      {activeTab === 'chat' && (
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2.5 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <MessageCircleHeart className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <span>Shireenzs Apki Sakhi • Voice & Chat</span>
                  {isSpeaking && (
                    <span className="flex items-center gap-1 text-xs text-rose-400 font-mono font-normal">
                      <Volume2 className="w-3.5 h-3.5 animate-pulse" /> Sakhi bol rahi hain...
                    </span>
                  )}
                </h2>
                <p className="text-xs text-slate-400">
                  Speaks and understands any language with respect, care and biometric awareness
                </p>
              </div>
            </div>
          </div>

          {/* Conversation Stream */}
          <div className="my-4 h-96 overflow-y-auto space-y-3.5 pr-2 custom-scrollbar">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed shadow-md ${
                    msg.sender === 'user'
                      ? 'bg-rose-600 text-white rounded-br-none'
                      : msg.sender === 'system'
                      ? 'bg-amber-950/60 text-amber-200 border border-amber-500/30'
                      : 'bg-slate-950 text-slate-100 border border-slate-800/80 rounded-bl-none'
                  }`}
                >
                  {msg.sender === 'ai' && (
                    <div className="flex items-center gap-1.5 text-[11px] font-mono text-rose-300 mb-1">
                      <Sparkles className="w-3 h-3 text-rose-400" />
                      <span className="font-bold">Shireenzs Apki Sakhi</span>
                      {msg.pulseAtMoment && (
                        <span className="text-slate-400 ml-1">
                          • Recorded at {msg.pulseAtMoment} BPM
                        </span>
                      )}
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <div className="mt-1 flex items-center justify-end gap-1.5 text-[10px] text-slate-400/80 font-mono">
                    {msg.isVoiceInput && <span>Voice In • </span>}
                    <span>{msg.timestamp}</span>
                  </div>
                </div>
              </motion.div>
            ))}

            {isLoadingAI && (
              <div className="flex items-center gap-2 text-rose-400 text-xs font-mono py-2">
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Sakhi is thinking with love and analyzing pulse telemetry...</span>
              </div>
            )}

            <div ref={chatBottomRef} />
          </div>

          {/* Suggested Quick Inquiries */}
          <div className="flex flex-wrap gap-2 pt-2 pb-3">
            <button
              onClick={() => onSendMessage('Sakhi, mera aaj ka swasthya aur pulse kaisa hai?')}
              className="px-3 py-1.5 rounded-full bg-slate-950 hover:bg-rose-950 text-rose-300 border border-rose-500/20 text-xs transition-all"
            >
              "Mera pulse aur swasthya kaisa hai?"
            </button>
            <button
              onClick={() => onSendMessage('Dawai aur hydration ka daily routine bataiye.')}
              className="px-3 py-1.5 rounded-full bg-slate-950 hover:bg-rose-950 text-rose-300 border border-rose-500/20 text-xs transition-all"
            >
              "Dawai aur hydration routine"
            </button>
            <button
              onClick={() => onSendMessage('Mujhe sukoon aur shaanti ke liye thoda guide kijiye.')}
              className="px-3 py-1.5 rounded-full bg-slate-950 hover:bg-rose-950 text-rose-300 border border-rose-500/20 text-xs transition-all"
            >
              "Sukoon aur shaanti ke liye guide"
            </button>
          </div>

          {/* Input Bar & Mic Trigger */}
          <form onSubmit={handleSend} className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={onToggleMic}
              className={`p-3.5 rounded-2xl font-semibold transition-all shadow-md shrink-0 cursor-pointer ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse ring-4 ring-rose-500/30'
                  : 'bg-slate-950 hover:bg-slate-800 text-rose-400 border border-slate-800 hover:border-rose-500/50'
              }`}
              title={isListening ? 'Stop recording' : `Speak with Sakhi in ${selectedLangObj.name}`}
            >
              <Mic className="w-5 h-5" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Sakhi se baat karein kisi bhi bhasha mein (Hindi, Urdu, English, etc.)...`}
              className="flex-1 px-4 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-rose-500 transition-colors"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isLoadingAI}
              className="p-3.5 rounded-2xl bg-rose-500 hover:bg-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold transition-all shadow-md shrink-0 cursor-pointer"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      )}

      {/* Tab 3: Wearable Test Scenarios & Telemetry Simulation */}
      {activeTab === 'telemetry' && (
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <h3 className="font-extrabold text-white text-base">
                Wearable Pulse Telemetry Testing Controls
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-rose-400">Manual Slider:</span>
              <input
                type="range"
                min="45"
                max="165"
                value={telemetry.bpm}
                onChange={(e) => onManualBpmChange(Number(e.target.value))}
                className="w-28 accent-rose-400 cursor-pointer"
              />
              <span className="text-xs font-mono font-bold text-white w-14 text-right">
                {telemetry.bpm} BPM
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-400">
            Test how Shireenzs Apki Sakhi proactively intercepts unusual heart rates and speaks out loud with respectful elder care instructions.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <button
              onClick={() => onSimulateScenario('normal')}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left transition-all"
            >
              <div className="font-bold text-emerald-400 text-sm">Resting State (72 BPM)</div>
              <div className="text-xs text-slate-400 mt-1">Calm breathing and serene vitals</div>
            </button>

            <button
              onClick={() => onSimulateScenario('meditation')}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-teal-500/40 text-left transition-all"
            >
              <div className="font-bold text-teal-300 text-sm">Morning Walk / Meditation (62 BPM)</div>
              <div className="text-xs text-slate-400 mt-1">Relaxed parasympathetic tone</div>
            </button>

            <button
              onClick={() => onSimulateScenario('spike')}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 text-left transition-all"
            >
              <div className="font-bold text-amber-400 text-sm">Sudden Pulse Spike (138 BPM)</div>
              <div className="text-xs text-slate-400 mt-1">Triggers Sakhi hydration & sit down nudge</div>
            </button>

            <button
              onClick={() => onSimulateScenario('panic')}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-rose-500/40 text-left transition-all"
            >
              <div className="font-bold text-rose-400 text-sm">High Tachycardia / Panic (155 BPM)</div>
              <div className="text-xs text-slate-400 mt-1">Triggers family alert recommendation</div>
            </button>

            <button
              onClick={() => onSimulateScenario('workout')}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left transition-all"
            >
              <div className="font-bold text-cyan-400 text-sm">Cardio Activity (128 BPM)</div>
              <div className="text-xs text-slate-400 mt-1">Advises pacing down</div>
            </button>
          </div>
        </div>
      )}

      {/* Tab 4: Health Alerts History */}
      {activeTab === 'alerts' && (
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-md">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <h3 className="font-extrabold text-white text-base">
                Biometric & Routine Alerts Log
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">{alerts.length} events logged</span>
          </div>

          <div className="mt-4 space-y-3">
            {alerts.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs">
                No acute biometric warnings recorded. Vitals are healthy.
              </div>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3"
                >
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-sm">{alert.title}</span>
                      <span className="text-xs font-mono text-slate-400">{alert.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1">{alert.message}</p>
                    <div className="text-[10px] text-rose-300 font-mono mt-1">
                      Logged at {alert.bpm} BPM
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Biofeedback Modal */}
      <AnimatePresence>
        {showBreathingModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
          >
            <div className="w-full max-w-md">
              <BreathingGuide
                currentBpm={telemetry.bpm}
                onClose={() => setShowBreathingModal(false)}
                onPacingComplete={() => {
                  onManualBpmChange(Math.max(65, telemetry.bpm - 15));
                }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
