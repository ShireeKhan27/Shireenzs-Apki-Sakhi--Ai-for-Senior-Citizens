import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Watch,
  Heart,
  Mic,
  Wind,
  ShieldAlert,
  Battery,
  Sparkles,
  Pill,
  CheckCircle,
} from 'lucide-react';
import { PulseTelemetry, ChatMessage, SeniorRoutineState } from '../types';
import { triggerHapticBuzz, playHUDAlertPing } from '../utils/audio';

interface WatchFaceProps {
  telemetry: PulseTelemetry;
  messages: ChatMessage[];
  isListening: boolean;
  onToggleMic: () => void;
  activeLanguage: string;
  onOpenBreathing: () => void;
  onQuickWhisper: (query: string) => void;
  isSpeaking: boolean;
  latestAlert?: string;
  routineState?: SeniorRoutineState;
  onTriggerSOS?: () => void;
}

export const WatchFace: React.FC<WatchFaceProps> = ({
  telemetry,
  messages,
  isListening,
  onToggleMic,
  activeLanguage,
  onOpenBreathing,
  onQuickWhisper,
  isSpeaking,
  latestAlert,
  routineState,
  onTriggerSOS,
}) => {
  const [activeTab, setActiveTab] = useState<'vitals' | 'ai' | 'medicine'>('vitals');

  const handleMicPress = () => {
    triggerHapticBuzz();
    playHUDAlertPing('whisper');
    onToggleMic();
  };

  const lastAiMessage = [...messages].reverse().find((m) => m.sender === 'ai');
  const nextMedicine = routineState?.medicines.find((m) => !m.taken);

  // Calculate percentage of circular progress for BPM (40 to 180 range)
  const bpmPercent = Math.min(100, Math.max(0, ((telemetry.bpm - 40) / 140) * 100));
  const circumference = 2 * Math.PI * 110;
  const strokeDashoffset = circumference - (bpmPercent / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center p-4">
      {/* Realistic Smartwatch Enclosure */}
      <div className="relative w-[340px] sm:w-[380px] h-[480px] flex items-center justify-center">
        {/* Watch Straps (Top & Bottom) */}
        <div className="absolute -top-10 w-36 h-20 bg-slate-800 rounded-t-3xl border-x-4 border-slate-700/60 shadow-lg" />
        <div className="absolute -bottom-10 w-36 h-20 bg-slate-800 rounded-b-3xl border-x-4 border-slate-700/60 shadow-lg" />

        {/* Watch Crown Button (Side) */}
        <div className="absolute -right-3 top-1/2 -translate-y-8 w-4 h-12 bg-gradient-to-r from-slate-600 to-slate-400 rounded-r-md shadow-md border border-slate-500" />
        <div className="absolute -right-2 top-1/2 translate-y-8 w-3 h-8 bg-slate-700 rounded-r-sm shadow-sm" />

        {/* Circular AMOLED Watch Bezel */}
        <div className="relative w-[320px] sm:w-[350px] h-[320px] sm:h-[350px] rounded-full p-2.5 bg-gradient-to-br from-slate-700 via-slate-900 to-slate-950 shadow-[0_20px_50px_rgba(0,0,0,0.8)] border-4 border-slate-700/80 flex items-center justify-center">
          {/* Glass Screen Edge Bevel */}
          <div className="relative w-full h-full rounded-full bg-slate-950 p-4 flex flex-col items-center justify-between overflow-hidden shadow-inner border border-slate-800">
            {/* Circular Progress Gauge */}
            <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none p-2">
              <circle
                cx="50%"
                cy="50%"
                r="110"
                stroke="#1e293b"
                strokeWidth="7"
                fill="transparent"
              />
              <circle
                cx="50%"
                cy="50%"
                r="110"
                stroke={
                  telemetry.bpm > 115
                    ? '#f43f5e'
                    : telemetry.bpm > 95
                    ? '#f59e0b'
                    : '#fb7185'
                }
                strokeWidth="7"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-700 ease-out"
              />
            </svg>

            {/* Top Watch Header */}
            <div className="relative z-10 w-full flex items-center justify-between px-6 pt-2 text-[10px] font-mono text-slate-400">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                <span className="font-bold text-rose-300">SAKHI WRIST</span>
              </div>
              <div className="flex items-center gap-1 text-cyan-400">
                <Battery className="w-3.5 h-3.5" />
                <span>{telemetry.batteryLevel}%</span>
              </div>
            </div>

            {/* Center Dial Display: Dynamic Views */}
            <div className="relative z-10 flex flex-col items-center text-center my-auto px-4 w-full">
              {activeTab === 'vitals' && (
                <>
                  {/* Pulsating Heart Icon */}
                  <div className="relative flex items-center justify-center mb-1">
                    <motion.div
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{
                        repeat: Infinity,
                        duration: 60 / Math.max(40, telemetry.bpm),
                        ease: 'easeInOut',
                      }}
                      className="relative z-10"
                    >
                      <Heart
                        className={`w-7 h-7 ${
                          telemetry.bpm > 115
                            ? 'text-rose-500 fill-rose-500'
                            : telemetry.bpm > 95
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-rose-400 fill-rose-400'
                        }`}
                      />
                    </motion.div>
                  </div>

                  {/* BPM Digit */}
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white">
                      {telemetry.bpm}
                    </span>
                    <span className="text-xs uppercase font-bold text-slate-400">BPM</span>
                  </div>

                  {/* Physiological State Badge */}
                  <span
                    className={`mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      telemetry.bpm > 115
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : telemetry.bpm > 95
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {telemetry.status}
                  </span>

                  {/* Elder Care Glance Pill */}
                  {nextMedicine && (
                    <div className="mt-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-[10px] text-amber-200 flex items-center gap-1.5 font-sans">
                      <Pill className="w-3 h-3 text-amber-400 shrink-0" />
                      <span className="truncate max-w-[170px]">
                        Due {nextMedicine.time}: {nextMedicine.name}
                      </span>
                    </div>
                  )}

                  {/* Secondary Vitals Row */}
                  <div className="mt-2 flex items-center justify-center gap-3 text-[11px] font-mono text-slate-300">
                    <div>
                      <span className="text-slate-500 block text-[9px]">STRESS</span>
                      <span className="font-bold text-cyan-300">{telemetry.stressLevel}%</span>
                    </div>
                    <span className="text-slate-700">|</span>
                    <div>
                      <span className="text-slate-500 block text-[9px]">SPO₂</span>
                      <span className="font-bold text-emerald-300">{telemetry.spo2}%</span>
                    </div>
                    <span className="text-slate-700">|</span>
                    <div>
                      <span className="text-slate-500 block text-[9px]">WATER</span>
                      <span className="font-bold text-teal-300">
                        {routineState ? `${routineState.glassesOfWater}/8` : '4/8'}
                      </span>
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'medicine' && (
                <div className="max-h-36 overflow-y-auto px-2 text-left w-full custom-scrollbar">
                  <div className="flex items-center gap-1.5 text-amber-400 text-[10px] font-mono uppercase mb-1">
                    <Pill className="w-3 h-3" />
                    <span>Senior Medicine Routine</span>
                  </div>
                  {routineState?.medicines.map((m) => (
                    <div
                      key={m.id}
                      className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 mb-1 text-[11px] flex items-center justify-between"
                    >
                      <div>
                        <div className={`font-bold ${m.taken ? 'line-through text-slate-500' : 'text-white'}`}>
                          {m.name}
                        </div>
                        <div className="text-[9px] text-slate-400 font-mono">{m.time} • {m.dosage}</div>
                      </div>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded ${m.taken ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'}`}>
                        {m.taken ? 'Taken' : 'Due'}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'ai' && (
                <div className="max-h-36 overflow-y-auto px-2 text-left">
                  <div className="flex items-center gap-1.5 text-rose-400 text-[10px] font-mono uppercase mb-1">
                    <Sparkles className="w-3 h-3" />
                    <span>Apki Sakhi Voice Whisper</span>
                  </div>
                  <p className="text-xs text-white font-medium leading-snug">
                    {lastAiMessage
                      ? lastAiMessage.text
                      : `Aapka pulse ${telemetry.bpm} BPM par sthir hai. Tap the mic button to speak with Sakhi in any language.`}
                  </p>
                  {latestAlert && (
                    <div className="mt-2 p-1.5 rounded-lg bg-rose-500/20 border border-rose-500/40 text-[10px] text-rose-200">
                      {latestAlert}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Watch Bottom Quick Action Buttons */}
            <div className="relative z-10 w-full flex items-center justify-center gap-2 pb-2">
              <button
                onClick={() =>
                  setActiveTab(activeTab === 'vitals' ? 'medicine' : activeTab === 'medicine' ? 'ai' : 'vitals')
                }
                className={`p-2 rounded-full transition-all ${
                  activeTab !== 'vitals'
                    ? 'bg-rose-500 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title="Toggle Pills & AI Whisper Screen"
              >
                {activeTab === 'medicine' ? <Sparkles className="w-4 h-4" /> : <Pill className="w-4 h-4" />}
              </button>

              <button
                onClick={handleMicPress}
                className={`p-3 rounded-full shadow-lg transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse ring-4 ring-rose-500/30'
                    : 'bg-rose-500 hover:bg-rose-400 text-white'
                }`}
                title="Tap to speak to Sakhi"
              >
                <Mic className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  triggerHapticBuzz();
                  if (onTriggerSOS) onTriggerSOS();
                  else onOpenBreathing();
                }}
                className="p-2 rounded-full bg-red-950/80 border border-red-500/40 text-red-300 hover:bg-red-900 transition-all"
                title="Wrist Emergency SOS Alert"
              >
                <ShieldAlert className="w-4 h-4 text-red-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Companion Wrist Info Badge */}
      <div className="mt-4 text-center">
        <p className="text-xs text-slate-400 font-mono">
          Shireenzs Apki Sakhi Wrist Edition • Medicine Nudges & Pulse Care
        </p>
        <p className="text-[11px] text-rose-300/80 mt-0.5">
          Dedicated AMOLED wrist companion with medicine schedules & haptic emergency SOS
        </p>
      </div>
    </div>
  );
};
